#'MultiLLCoperation()
#'
#' @description MultiLLCoperation function finds out all edges between treatment units and control units. It finds finds the several largest connected graph
#' @param dataframe a dataframe contains covariables for distance, response and treatment
#' @param start the index of start column in dataframe for covariables
#' @param end the index of end column in dataframe for covariables
#' @param criticalvalue the critical value to determine if there is an edge
#' @param standerdize option if to standerdize the covariance,default value is TRUE
#' @param trt an integer shows which column is the trt
#' @examples step one:df=MultiLLCoperation(dataframe=yourdataframe,start=int1,end=int2,criticalvalue=w,standerdize=TRUE)
#' @examples step two:LLCgetLargest(dflist=df,bytrtsize=TRUE, order=c(1:3))
#' @author Hongyuan Lu




#' @export 
MultiLLCoperation=function(dataframe=NULL,start=NULL,end=NULL, trt=NULL,criticalvalue=NULL,standerdize=TRUE)
{ 
  if(is.null(dataframe))
  {print("error: no dataframe")
    return()
  }
  
  if(is.null(start))
  {print("error: no start index")
    return()
  }
  
  if(is.null(end))
  {print("error: no end index")
    return()
  }
  
  if(is.null(criticalvalue))
  {print("error: no criticalvalue") 
    return ()
  }
  
  
  
  library(reticulate,warn.conflicts=F)
  #source_python("./R/multiLLC.py")
  source_python(paste(.libPaths(),"/llc/exec/multiLLC.py",sep=""))
  
  templateframe=dataframe
  
  if(standerdize==TRUE)
  {templateframe[,start:end]=apply(templateframe[,start:end],2,scale)}
  
  
  trtindex=which(templateframe[trt]==1)
  conindex=which(templateframe[trt]==0)
  trt=templateframe[trtindex,]
  con=templateframe[conindex,]
  
  trtcov=trt[,start:end]
  concov=con[,start:end]
  
  inputsize=dim(templateframe)[1]
  result=DLCoperation(trtcov,concov,criticalvalue,inputsize)
  
  
  alltrtindex=c()
  allindex=c()
  idorder=c()
  id=1
  while(id<=length(result))
  { 
    alltrtindex=c(  alltrtindex,length( unlist(  result[[id]][[1]])  )    )
    allindex=c(allindex,length(unlist(result[[id]][[1]]))+length( unlist(result[[id]][[2]])  ) )
    idorder=c(idorder,id)
    id=id+1
    
  }
  
  trtorder=sort(alltrtindex,decreasing=TRUE,index.return=TRUE)$ix
  allorder=sort(allindex,decreasing=TRUE,index.return=TRUE)$ix
  
  trtresultorder=idorder[trtorder]
  allresultorder=idorder[allorder]
  
  #*****************
  # if size>length(result){size=length}
  # trtframes=c()
  # allframes=c()
  # i=1
  # while(i<size)
  # {resulttrtindex=unlist(result[[trtresultorder[i]]][[1]])+1
  #  resultconindex=unlist(result[[trtresultorder[i]]][[2]])+1
  #  rtrt=dataframe[resulttrtindex,]
  #  rcon=dataframe[resultconindex,]
  #  trtframes=c(trtframes,rbind(rtrt,rcon))
  #  i=i+1
  # }
  
  return(list(dataframe,result,trtresultorder,allresultorder))
}

#'MultiLLCMahalanobis()
#'
#' @description MultiLLCMahalanobis function finds out all edges between treatment units and control units. It finds finds the several largest connected graph
#' @param dataframe a dataframe contains covariables for distance, response and treatment
#' @param start the index of start column in dataframe for covariables
#' @param end the index of end column in dataframe for covariables
#' @param criticalvalue the critical value to determine if there is an edge
#' @param standerdize option if to standerdize the covs. The default value is TRUE
#' @param trt an integer shows which column is the trt
#' @param inverted if inverted is true then you should invert covs using solve yourself, default is false 
#' @param covs the covariance matrix(p*p) of the distribution
#' @examples MultiLLCoperation(dataframe=yourdataframe,start=int1,end=int2,criticalvalue=w,standerdize=TRUE)
#' @examples step two:LLCgetLargest(dflist=df,bytrtsize=TRUE, order=c(1:3))
#' @author Hongyuan Lu




#' @export 
MultiLLCMahalanobis=function(dataframe=NULL,start=NULL,end=NULL,trt=NULL,criticalvalue=NULL,standerdize=TRUE,inverted=FALSE,covs=NULL)
{
  if(is.null(dataframe))
  {print("error: no dataframe")
    return()
  }
  
  if(is.null(start))
  {print("error: no start index")
    return()
  }
  
  if(is.null(end))
  {print("error: no end index")
    return()
  }
  
  if(is.null(criticalvalue))
  {print("error: no criticalvalue") 
    return ()
  }
  if(is.null(covs))
  {
    print("error: no covs")
  }
  
  in_covs=covs
  if(inverted==FALSE)
  {in_covs=solve(covs)}
  
  library(reticulate,warn.conflicts=F)
  #source_python("./R/DLCmahalanobis.py")
  source_python(paste(.libPaths(),"/llc/exec/DLCmahalanobis.py",sep=""))
  
  orderedkey=colnames(dataframe)[start:end]
  templateframe=dataframe
  
  
  if(standerdize==TRUE)
  {templateframe[,start:end]=apply(templateframe[,start:end],2,scale)}
  
  
  trtindex=which(templateframe[trt]==1)
  conindex=which(templateframe[trt]==0)
  trt=templateframe[trtindex,]
  con=templateframe[conindex,]
  
  trtcov=trt[,start:end]
  concov=con[,start:end]
  
  result=DLCoperation(orderedkey,trtcov,concov,criticalvalue,in_covs)
  
  
  alltrtindex=c()
  allindex=c()
  idorder=c()
  id=1
  while(id<=length(result))
  { 
    alltrtindex=c(  alltrtindex,length( unlist(  result[[id]][[1]])  )    )
    allindex=c(allindex,length(unlist(result[[id]][[1]]))+length( unlist(result[[id]][[2]])  ) )
    idorder=c(idorder,id)
    id=id+1
    
  }
  
  trtorder=sort(alltrtindex,decreasing=TRUE,index.return=TRUE)$ix
  allorder=sort(allindex,decreasing=TRUE,index.return=TRUE)$ix
  
  trtresultorder=idorder[trtorder]
  allresultorder=idorder[allorder]
  
  #*****************
  # if size>length(result){size=length}
  # trtframes=c()
  # allframes=c()
  # i=1
  # while(i<size)
  # {resulttrtindex=unlist(result[[trtresultorder[i]]][[1]])+1
  #  resultconindex=unlist(result[[trtresultorder[i]]][[2]])+1
  #  rtrt=dataframe[resulttrtindex,]
  #  rcon=dataframe[resultconindex,]
  #  trtframes=c(trtframes,rbind(rtrt,rcon))
  #  i=i+1
  # }
  
  return(list(dataframe,result,trtresultorder,allresultorder))
}


#'LargestCaliper()
#'
#' @description LargestCaliper function finds out all edges between treatment units and control units using largest caliper. It finds finds the several largest connected graph
#' @param dataframe a dataframe contains covariables for distance, response and treatment
#' @param start the index of start column in dataframe for covariables
#' @param end the index of end column in dataframe for covariables
#' @param trt an integer shows which column is the trt
#' @param criticalvalue the critical value to determine if there is an edge
#' @param standerdize option if to standerdize the covs. The default value is TRUE
#' @param weights a vector of size p, determint the weights
#' @examples LargestCaliper(dataframe=yourdataframe,start=int1,end=int2,criticalvalue=w,standerdize=TRUE,weights=weigthsvector)
#' @examples step two:LLCgetLargest(dflist=df,bytrtsize=TRUE, order=c(1:3))
#' @author Hongyuan Lu




#' @export 
LargestCaliper=function(dataframe=NULL,start=NULL,end=NULL,trt=NULL,criticalvalue=NULL,standerdize=TRUE,weights=NULL)
{ 
  
  
  if(is.null(dataframe))
  {print("error: no dataframe")
    return()
  }
  
  if(is.null(start))
  {print("error: no start index")
    return()
  }
  
  if(is.null(end))
  {print("error: no end index")
    return()
  }
  
  if(is.null(weights)){print("error: no weights")}
  if(length(weights)!=end-start+1)
  {
    print("error: wrong weights size")
  }
  
  if(is.null(criticalvalue))
  {print("error: no criticalvalue") 
    return ()
  }
  
  
  library(reticulate,warn.conflicts=F)
  #source_python("./R/LargestCaliper.py")
  source_python(paste(.libPaths(),"/llc/exec/LargestCaliper.py",sep=""))

  
  orderedkey=colnames(dataframe)[start:end]
  templateframe=dataframe
  
  
  if(standerdize==TRUE)
  {templateframe[,start:end]=apply(templateframe[,start:end],2,scale)}
  
  
  trtindex=which(templateframe[trt]==1)
  conindex=which(templateframe[trt]==0)
  trt=templateframe[trtindex,]
  con=templateframe[conindex,]
  
  trtcov=trt[,start:end]
  concov=con[,start:end]
  
  result=DLCoperation(orderedkey,trtcov,concov,criticalvalue,weights)
  
  
  alltrtindex=c()
  allindex=c()
  idorder=c()
  id=1
  while(id<=length(result))
  { 
    alltrtindex=c(  alltrtindex,length( unlist(  result[[id]][[1]])  )    )
    allindex=c(allindex,length(unlist(result[[id]][[1]]))+length( unlist(result[[id]][[2]])  ) )
    idorder=c(idorder,id)
    id=id+1
    
  }
  
  trtorder=sort(alltrtindex,decreasing=TRUE,index.return=TRUE)$ix
  allorder=sort(allindex,decreasing=TRUE,index.return=TRUE)$ix
  
  trtresultorder=idorder[trtorder]
  allresultorder=idorder[allorder]
  
  #*****************
  # if size>length(result){size=length}
  # trtframes=c()
  # allframes=c()
  # i=1
  # while(i<size)
  # {resulttrtindex=unlist(result[[trtresultorder[i]]][[1]])+1
  #  resultconindex=unlist(result[[trtresultorder[i]]][[2]])+1
  #  rtrt=dataframe[resulttrtindex,]
  #  rcon=dataframe[resultconindex,]
  #  trtframes=c(trtframes,rbind(rtrt,rcon))
  #  i=i+1
  # }
  
  return(list(dataframe,result,trtresultorder,allresultorder))
}

#'LLCgivendistances()
#'
#' @description LLCgivendistances function finds out all edges between treatment units and control units. It finds finds the several largest connected graph
#' @param dataframe a dataframe contains covariables for distance, response and treatment
#' @param trt an integer shows which column is the trt
#' @param criticalvalue the critical value to determine if there is an edge
#' @examples step one:df=LLCgivendistances(dataframe=yourdataframe,criticalvalue=w,standerdize=TRUE)
#' @examples step two:LLCgetLargest(dflist=df,bytrtsize=TRUE, order=c(1:3))
#' @author Hongyuan Lu




#' @export 
LLCgivendistances=function(dataframe=NULL,trt=NULL,criticalvalue=NULL,distances=NULL)
{
  if(is.null(dataframe))
  {print("error: no dataframe")
    return()
  }
  
  
  if(is.null(criticalvalue))
  {print("error: no criticalvalue") 
    return ()
  }
  
  
  
  library(reticulate,warn.conflicts=F)
  #source_python("./R/givendistance.py")
  source_python(paste(.libPaths(),"/llc/exec/givendistance.py",sep=""))
  
  trtindex=which(dataframe[trt]==1)
  conindex=which(dataframe[trt]==0)
  trt=dataframe[trtindex,]
  con=dataframe[conindex,]
  
  if(dim(distances)[1]!=length(trtindex) || length(conindex)!=dim(distances)[2]){print("error: the distances matrix is in wrong dimension")}
  
  trtcov=trt[,1]
  concov=con[,1]
  result=DLCoperation(trtcov,concov,criticalvalue,distances)
  
  
  alltrtindex=c()
  allindex=c()
  idorder=c()
  id=1
  while(id<=length(result))
  { 
    alltrtindex=c(  alltrtindex,length( unlist(  result[[id]][[1]])  )    )
    allindex=c(allindex,length(unlist(result[[id]][[1]]))+length( unlist(result[[id]][[2]])  ) )
    idorder=c(idorder,id)
    id=id+1
    
  }
  
  trtorder=sort(alltrtindex,decreasing=TRUE,index.return=TRUE)$ix
  allorder=sort(allindex,decreasing=TRUE,index.return=TRUE)$ix
  
  trtresultorder=idorder[trtorder]
  allresultorder=idorder[allorder]
  
  #*****************
  # if size>length(result){size=length}
  # trtframes=c()
  # allframes=c()
  # i=1
  # while(i<size)
  # {resulttrtindex=unlist(result[[trtresultorder[i]]][[1]])+1
  #  resultconindex=unlist(result[[trtresultorder[i]]][[2]])+1
  #  rtrt=dataframe[resulttrtindex,]
  #  rcon=dataframe[resultconindex,]
  #  trtframes=c(trtframes,rbind(rtrt,rcon))
  #  i=i+1
  # }
  
  return(list(dataframe,result,trtresultorder,allresultorder))
}




#'LLCabspropensity()
#'
#' @description LLCabspropensity function finds out all edges between treatment units and control units. It finds finds the several largest connected graph
#' @param dataframe a dataframe contains covariables for distance, response and treatment
#' @param trt an integer shows which column is the trt
#' @param criticalvalue the critical value to determine if there is an edge
#' @propensity propensity scores, a vector or a data frame used to caculate distances
#' @examples step one:df=LLCgivendistances(dataframe=yourdataframe,criticalvalue=w,standerdize=TRUE)
#' @examples step two:LLCgetLargest(dflist=df,bytrtsize=TRUE, order=c(1:3))
#' @author Hongyuan Lu




#' @export 
LLCabspropensityscore=function(dataframe=NULL,trt=NULL,criticalvalue=NULL,propensity=NULL)
{
  if(is.null(dataframe))
  {print("error: no dataframe")
    return()
  }
  
  
  if(is.null(criticalvalue))
  {print("error: no criticalvalue") 
    return ()
  }
  
  if(dim(dataframe)[1]!=length(unlist(propensity)))
  {
    print("error:propensity score in wrong dimensiion")
    return ()
  }

  
  
  
  library(reticulate,warn.conflicts=F)
  #setwd("~/Desktop/Research/llc")
  #source_python("./exec/llcpropensity.py")
  
  source_python(paste(.libPaths(),"/llc/exec/llcpropensity.py",sep=""))
  
  if(class(propensity)==class(data.frame())  )
  {propensity=as.vector(unlist(propensity))}  
  
  propensity=data.frame("prop"=propensity)
    
 
  
  trtindex=which(dataframe[trt]==1)
  conindex=which(dataframe[trt]==0)
  tprop=data.frame("prop"=propensity[trtindex,])
  cprop=data.frame("prop"=propensity[conindex,])
  
 
  
  
  result=DLCoperation(tprop,cprop,criticalvalue)
  
  
  alltrtindex=c()
  allindex=c()
  idorder=c()
  id=1
  while(id<=length(result))
  { 
    alltrtindex=c(  alltrtindex,length( unlist(  result[[id]][[1]])  )    )
    allindex=c(allindex,length(unlist(result[[id]][[1]]))+length( unlist(result[[id]][[2]])  ) )
    idorder=c(idorder,id)
    id=id+1
    
  }
  
  trtorder=sort(alltrtindex,decreasing=TRUE,index.return=TRUE)$ix
  allorder=sort(allindex,decreasing=TRUE,index.return=TRUE)$ix
  
  trtresultorder=idorder[trtorder]
  allresultorder=idorder[allorder]
  
  #*****************
  # if size>length(result){size=length}
  # trtframes=c()
  # allframes=c()
  # i=1
  # while(i<size)
  # {resulttrtindex=unlist(result[[trtresultorder[i]]][[1]])+1
  #  resultconindex=unlist(result[[trtresultorder[i]]][[2]])+1
  #  rtrt=dataframe[resulttrtindex,]
  #  rcon=dataframe[resultconindex,]
  #  trtframes=c(trtframes,rbind(rtrt,rcon))
  #  i=i+1
  # }
  
  return(list(dataframe,result,trtresultorder,allresultorder))
}





#'LLCgetLargest()
#'
#' @description LLCgetLargest function gives the largest several connected graphs according to trt size or total size using the result from MultiLLCoperation
#' @param dflist result in list from MultiLLCoperation function
#' @param trt the integer showing in original data, which column is the trt
#' @param bytrtsize option if the largest connected graphs has the largest trt size or total size,defalt value is false
#' @param order an integer or a vector showing which largest connected graphs
#' @param bindit if we want to rbind all the selected dataframes, default value is false
#' @examples  Step One:df=MultiLLCoperation(dataframe=mydata,start=2,end=4,criticalvalue = 0.6,size=10)
#' @examples  Step Two:LLCgetLargest(dflist=df,bytrtsize=TRUE, order=c(1:3))
#' @author Hongyuan Lu
#' @export 
LLCgetLargest=function(dflist=NULL,trt=NULL,bytrtsize=FALSE,order=NULL,bindit=FALSE)
{ 
  if(is.null(dflist))
  {print("error: dflist is Wrong")}
  
  
  
  df=dflist[[1]]
  trtindex=which(df[trt]==1)
  conindex=which(df[trt]==0)
  trt=df[trtindex,]
  con=df[conindex,]
  
  
  result=dflist[[2]]
  limit=length(result)
  if(bytrtsize==TRUE)
  {indexorder=dflist[[3]]}else
  {indexorder=dflist[[4]]}
  
  if(is.null(order)){order=1}
  order=order[order<=limit]
  if(length(order)==0)
  {print ("error:order")
    return ()
    
  }
  
  if(length(order)==1){
    trtindex=unlist(result[[indexorder[order]]][[1]])+1
    conindex=unlist(result[[indexorder[order]]][[2]])+1
    resultdataframe=rbind(trt[trtindex,],con[conindex,])
    return(resultdataframe)
  }else
  {i=1
  resultlist=list()
  while(i<=length(order))
  {
    trtindex=unlist(result[[indexorder[order[i]]]][[1]])+1
    conindex=unlist(result[[indexorder[order[i]]]][[2]])+1
    resultlist[[i]]=rbind(trt[trtindex,],con[conindex,])
    
    i=i+1
  }
  if (bindit==FALSE){return(resultlist)}else{
    i=1
    ini=resultlist[[i]]
    while(i<length(resultlist))
       { i=i+1
         ini=rbind(ini,resultlist[[i]])
      
       }
       return(ini)
  }
  
  }
  
  
}