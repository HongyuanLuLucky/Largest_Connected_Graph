library(readr)
library(reticulate)
mydata <- data.frame(read_csv("~/Desktop/950/problem1data.csv.xls"))

trt=mydata[which(mydata["Trt"]==1),]
con=mydata[which(mydata["Trt"]==0),]

mtrt=trt[1:10,]
mcon=con[1:10,]
mdata=rbind(mtrt,mcon)

s=matrix(c(1,0.5,0.5,0.5,2,0.5,0.5,0.5,3),nrow=3,byrow=TRUE)
is=solve(s)
rm=matrix(c(1:100)*0,nrow=10)
i=1
while(i<=10)
{j=1
 while(j<=10)
 { v1=as.vector(unlist(mtrt[i,2:4]))
   v2=as.vector(unlist(mcon[j,2:4])) 
   rm[i,j]=mahalanobis(v1,v2,solve(s),inverted=TRUE)
   j=j+1
 }
i=i+1   
}

boolrm=(rm<3)

start=2;end=4
orderedKey=orderedkey=colnames(mtrt)[start:end]
source_python("~/Desktop/950/mahalanobis/DLCmahalanobis.py")
result=DLCoperation(orderedkey,mtrt[,start:end],mcon[,start:end],3,is)


v1=as.vector(unlist(mtrt[3,2:4]))
v2=as.vector(unlist(mcon[10,2:4]))            

r1=matrix(v1-v2,nrow=1)%*%solve(s)%*%matrix(v1-v2,nrow=3)
r2=mahalanobis(v1,v2,solve(s),inverted=TRUE)

trtindex=unlist(result[[1]])+1
conindex=unlist(result[[2]])+1

#*****************************
s=matrix(c(1,0.5,0.5,0.5,2,0.5,0.5,0.5,3),nrow=3,byrow=TRUE)
is=solve(s) 


rm=matrix(c(1:100)*0,nrow=10)
i=1
while(i<=10)
{j=1
while(j<=10)
{ v1=as.vector(unlist(mtrt[i,2:4]))
v2=as.vector(unlist(mcon[j,2:4])) 
rm[i,j]=mahalanobis(v1,v2,solve(s),inverted=TRUE)
j=j+1
}
i=i+1   
}

boolrm=(rm<2)
  
start=2;end=4
orderedKey=orderedkey=colnames(mtrt)[start:end]
source_python("~/Desktop/950/Multimahalanobis/DLCmahalanobis.py")
result=DLCoperation(orderedkey,mtrt[,start:end],mcon[,start:end],2,is)
trtindex=unlist(result[[1]][[1]])+1
conindex=unlist(result[[1]][[2]])+1


setwd("~/Desktop/950/Multimahalanobis")
setwd("~/Desktop/950/MultipleLLClargest")
setwd("~/Desktop/950/LLC")
library(readr)
library(cobalt)

mydata <- data.frame(read_csv("~/Desktop/950/problem1data.csv.xls"))

stdnewdata=LLCoperation(dataframe=mydata,start=2,end=4,criticalvalue =0.6,standerdize=FALSE)
stdtab=bal.tab(stdnewdata,treat=stdnewdata$Trt,covs=stdnewdata[,2:4])
love.plot(stdtab,line=TRUE)


df=MultiLLCoperation(dataframe=mydata,start=2,end=4,criticalvalue = 0.6)
r=LLCgetLargest(dflist=df,bytrtsize=FALSE,order=c(1:3))
ndata1=r[[1]]
ndata2=r[[2]]
ndata3=r[[3]]

oldtab=bal.tab(mydata,treat=mydata$Trt,covs=mydata[,2:4])
love.plot(oldtab,line=TRUE)

mybaltab=bal.tab(ndata1, treat = ndata1$Trt, covs = ndata1[,2:4])
love.plot(mybaltab,line=TRUE)


df=MultiLLCMahalanobis(dataframe=mdata,start=2,end=4,criticalvalue=2,inverted=FALSE,covs=s)
r=LLCgetLargest(dflist=df,bytrtsize=FALSE,order=c(1:2))
mdata1=r[[1]]
mdata1=r[[2]]

#*****************************************

setwd("~/Desktop/950/LargestCaliper")

mydata <- data.frame(read_csv("~/Desktop/950/problem1data.csv.xls"))

trt=mydata[which(mydata["Trt"]==1),]
con=mydata[which(mydata["Trt"]==0),]

mtrt=trt[1:10,]
mcon=con[1:10,]
mdata=rbind(mtrt,mcon)
weights=c(2,5,10)

rm=matrix(c(1:100)*0,nrow=10)

i=1
while(i<=10)
{ j=1
  while(j<=10)
  {
   rm[i,j]=max(abs( as.vector(unlist(mtrt[i,2:4]))-as.vector(unlist(mcon[j,2:4])) )/weights )
   j=j+1
  }
  i=i+1
}

boolrm=(rm<0.3)

source_python("~/Desktop/950/LargestCaliper/R/LargestCaliper.py")
r=DLCoperation(colnames(mdata)[2:4],mtrt[,2:4],mcon[,2:4],0.3,weights)
unlist(r[[1]][[1]])+1
unlist(r[[1]][[2]])+1


setwd("~/Desktop/950/LargestCaliper")
df=LargestCaliper(dataframe=mdata,start=2,end=4,criticalvalue = 0.3,weights = c(2,5,10))
res=LLCgetLargest(dflist=df,bytrtsize=FALSE,order=c(1:3))


setwd("~/Desktop/Research/llc")
df1=MultiLLCoperation(dataframe=mydata,start=2,end=4,criticalvalue = 0.6,standerdize=FALSE)
r1=LLCgetLargest(dflist=df1,bytrtsize=FALSE,order=c(1:3))


s=matrix(c(1,0.5,0.5,0.5,2,0.5,0.5,0.5,3),nrow=3,byrow=TRUE)
is=solve(s)
df2=MultiLLCMahalanobis(dataframe=mydata,start=2,end=4,criticalvalue=0.3,standerdize=FALSE,inverted=FALSE,covs=is)
r2=LLCgetLargest(dflist=df2,bytrtsize=FALSE,order=c(1:3))


weights=c(2,5,10)
df3=LargestCaliper(dataframe=mydata,start=2,end=4,criticalvalue = 0.3,standerdize=FALSE,weights=weights)
r3=LLCgetLargest(dflist=df3,bytrtsize=FALSE,order=c(1:3))

source_python("~/Desktop/950/review.py")

set.seed(999)
source_python("~/Desktop/Research/llc/R/givendistance.py")
dists=matrix(abs(rnorm(10*10)),nrow=10)
boolrm=(dists<0.1)
r=DLCoperation(mtrt[,2:4],mcon[,2:4],0.1,dists)
rt=unlist(r[[1]][[1]])+1
rc=unlist(r[[1]][[2]])+1

setwd("~/Desktop/Research/llc")

ini=r[[1]]
i=2
while(i<=54)
{ini=rbind(ini,r[[i]])
 i=i+1
  
}
