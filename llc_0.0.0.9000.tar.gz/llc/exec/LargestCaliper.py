import math
import numpy as np
import sys

key=None
dicttrt=None
dictcon=None
markedtrt=[]
markedcon=[]
ntrt=None
ncon=None
cri=None
count=0
nt=None
_weight_=None


def DLCoperation(orderedkey,adicttrt, adictcon, acri,ans):
    global dicttrt
    global dictcon
    global ntrt
    global ncon
    global markedtrt
    global markedcon
    global key
    global cri
    global count
    global _weight_
    _weight_=ans
    cri = acri
    if type(adicttrt) == type({}):
        dicttrt = adicttrt
        dictcon = adictcon
        key = orderedkey
    else:
        dicttrt = {"X1": adicttrt}
        dictcon = {"X1": adictcon}
        key = ["X1"]
    ntrt = len(dicttrt[dicttrt.keys()[0]])
    ncon = len(dictcon[dictcon.keys()[0]])
    markedtrt = [False] * ntrt
    markedcon = [False] * ncon



    result = searchLargestGraphs()
    dicttrt = None
    dictcon = None
    markedtrt = None

    markedcon = None

    ntrt = None
    ncon = None
    cri = None
    count = 0
    nt = None
    _weight_=None

    return result


def getDistanceEulucid(i, j):  ##R index
    global dicttrt
    global dictcon
    global key
    global count
    global _weight_
    templist=[]
    idx=0

    for item in key:
        #print key
        #print dicttrt[item][i]
        #print dictcon[item][j]
        #if i==9 and j==6:print "i=",i+1,":",float(dicttrt[item][i])," j=",j+1,":",float(dictcon[item][j])," item:",item,":"
        #print float(dicttrt[item][i]), "-",float(dicttrt[item][j])
        templist.append( abs((float(dicttrt[item][i])-float(dictcon[item][j])))/float(_weight_[idx])     )
        idx+=1

    #print i + 1, j + 1, "  :  ", templist
    #print i+1,j+1,"  :  ",max(templist)
    return max(templist)

    count += 1



# a=[-1.7475162, -0.62884739999999995, -1.9659701999999999]
# b=[0.025016429999999999, 1.9546972300000001, -2.1355578099999999]
#
# _weight_=[2,5,10]
# idx=0
#
# for item in [0,1,2]:
#     #print key
#     #print dicttrt[item][i]
#     #print dictcon[item][j]
#     print abs((float(a[item])-float(b[item])))/float(_weight_[idx])
#     idx+=1


def searchLargestGraphs():
    global ntrt
    global ncon
    global cri
    global markedtrt
    global markedcon
    global nt
    resulttrt = []
    resultcon = []
    result = []
    largest = []
    # templist=np.setdiff1d(range(ntrt),markedtrt)
    # while len(templist)>0:
    for tid in range(ntrt):
        if markedtrt[tid] == False:
            tempresult = searchForOneNode(tid, 1)
            # templist=np.setdiff1d(range(ntrt),markedtrt)
            resulttrt = tempresult[0]
            resultcon = tempresult[1]
            result.append([resulttrt, resultcon])

    return result


def searchForOneNode(index, tc):  ##python index
    global dicttrt
    global dictcon
    global markedtrt
    global markedcon
    global cri
    global ncon
    global ntrt
    stack = []
    resulttrt = []
    resultcon = []
    if not [index, tc] in stack:
        if tc == 1:
            markedtrt[index] = True  ##
            resulttrt.append(index)
        elif tc == 0:
            markedcon[index] = True  ##
            resultcon.append(index)
        stack.append([index, tc])

    else:
        return None
    while len(stack) > 0:
        temp = stack.pop()
        tempindex = temp[0]
        temptc = temp[1]
        if temptc == 1:
            for cindex in range(ncon):
                if markedcon[cindex] == False:
                    tempdist = getDistanceEulucid(tempindex, cindex)
                    if tempdist < cri:
                        markedcon[cindex] = True  #
                        stack.append([cindex, 0])  #
                        resultcon.append(cindex)  #
        if temptc == 0:
            for tindex in range(ntrt):
                if markedtrt[tindex] == False:
                    tempdist = getDistanceEulucid(tindex, tempindex)
                    if tempdist < cri:
                        markedtrt[tindex] = True
                        stack.append([tindex, 1])
                        resulttrt.append(tindex)

    return [resulttrt, resultcon]  ##returns python index


def PrintMatrix(amatrix):
    print amatrix
    print amatrix[0]
    print amatrix[1]
    print amatrix[2]
    print type(amatrix)
    return

##matrix is a list of list, every list element is one row in matrix
def TestMatrix(amatrix):
    for i in range(len(amatrix)):
        for j in range(len(amatrix[0])):
            print amatrix[i][j]
    return

def ifgood(amatrix):
    print amatrix
    print list(amatrix)
    print type(list(amatrix))
    print np.matrix(list(amatrix))
##matrix.array([1,2,3]) creates a 1 by 3 row matrix
## matrix.array([[1],[2],[3]]) creates a 3by 1 matrix

def printkey(atrtcov):
    print atrtcov.keys()

def printtype(ob):
    print ob
    print type(ob)