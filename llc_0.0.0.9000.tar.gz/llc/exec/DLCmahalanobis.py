import math
import numpy as np
import sys

key=None
dicttrt=None
dictcon=None
markedtrt=[]
markedcon=[]
ntrt=None
ncon=None
cri=None
count=0
nt=None
s_s=None


def DLCoperation(orderedkey,adicttrt, adictcon, acri,ans):
    global dicttrt
    global dictcon
    global ntrt
    global ncon
    global markedtrt
    global markedcon
    global key
    global cri
    global count
    global s_s
    cri = acri
    s_s=ans
    if type(adicttrt)==type({}):
        dicttrt=adicttrt
        dictcon=adictcon
        key=orderedkey
    else:
        dicttrt={"X1":adicttrt}
        dictcon={"X1":adictcon}
        key=["X1"]
    print key
    ntrt=len(dicttrt[dicttrt.keys()[0]])
    ncon=len(dictcon[dictcon.keys()[0]])
    markedtrt=[False]*ntrt
    markedcon=[False]*ncon

    result = searchLargestGraphs()
    dicttrt = None
    dictcon = None
    markedtrt = None
    markedcon = None
    ntrt = None
    ncon = None
    cri = None
    count = 0
    s_s=None
    return result


def getDistanceEulucid(i, j):  ##R index
    global dicttrt
    global dictcon
    global key
    global count
    global s_s
    rowvector=[]
    colvector=[]
    for item in key:
        #print key
        #print dicttrt[item][i]
        #print dictcon[item][j]
        rowvector.append(dicttrt[item][i]-dictcon[item][j])
        colvector.append([dicttrt[item][i]-dictcon[item][j]])

    rowmatrix=np.matrix(rowvector)
    colmatrix=np.matrix(colvector)
    #print i+1,j+1,"  :  ",float(rowmatrix*s_s*colmatrix)
    return float(rowmatrix*s_s*colmatrix)

    count += 1


def searchLargestGraphs():
    global ntrt
    global ncon
    global cri
    global markedtrt
    global markedcon
    global nt
    resulttrt = []
    resultcon = []
    result = []
    largest = []
    # templist=np.setdiff1d(range(ntrt),markedtrt)
    # while len(templist)>0:
    for tid in range(ntrt):
        if markedtrt[tid] == False:
            tempresult = searchForOneNode(tid, 1)
            # templist=np.setdiff1d(range(ntrt),markedtrt)
            resulttrt = tempresult[0]
            resultcon = tempresult[1]
            result.append([resulttrt, resultcon])

    return result


def searchForOneNode(index, tc):  ##python index
    global dicttrt
    global dictcon
    global markedtrt
    global markedcon
    global cri
    global ncon
    global ntrt
    stack = []
    resulttrt = []
    resultcon = []
    if not [index, tc] in stack:
        if tc == 1:
            markedtrt[index] = True  ##
            resulttrt.append(index)
        elif tc == 0:
            markedcon[index] = True  ##
            resultcon.append(index)
        stack.append([index, tc])

    else:
        return None
    while len(stack) > 0:
        temp = stack.pop()
        tempindex = temp[0]
        temptc = temp[1]
        if temptc == 1:
            for cindex in range(ncon):
                if markedcon[cindex] == False:
                    tempdist = getDistanceEulucid(tempindex, cindex)
                    if tempdist < cri:
                        markedcon[cindex] = True  #
                        stack.append([cindex, 0])  #
                        resultcon.append(cindex)  #
        if temptc == 0:
            for tindex in range(ntrt):
                if markedtrt[tindex] == False:
                    tempdist = getDistanceEulucid(tindex, tempindex)
                    if tempdist < cri:
                        markedtrt[tindex] = True
                        stack.append([tindex, 1])
                        resulttrt.append(tindex)

    return [resulttrt, resultcon]  ##returns python index


def PrintMatrix(amatrix):
    print amatrix
    print amatrix[0]
    print amatrix[1]
    print amatrix[2]
    print type(amatrix)
    return

##matrix is a list of list, every list element is one row in matrix
def TestMatrix(amatrix):
    for i in range(len(amatrix)):
        for j in range(len(amatrix[0])):
            print amatrix[i][j]
    return

def ifgood(amatrix):
    print amatrix
    print list(amatrix)
    print type(list(amatrix))
    print np.matrix(list(amatrix))
##matrix.array([1,2,3]) creates a 1 by 3 row matrix
## matrix.array([[1],[2],[3]]) creates a 3by 1 matrix

def printkey(atrtcov):
    print atrtcov.keys()

def printtype(ob):
    print ob
    print type(ob)