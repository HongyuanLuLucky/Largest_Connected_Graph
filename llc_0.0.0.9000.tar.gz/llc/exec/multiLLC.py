import math
import numpy as np
import sys

key=None
dicttrt=None
dictcon=None
markedtrt=[]
markedcon=[]
ntrt=None
ncon=None
cri=None
count=0
nt=None

def DLCoperation(adicttrt, adictcon, acri,an):
    global dicttrt
    global dictcon
    global ntrt
    global ncon
    global markedtrt
    global markedcon
    global key
    global cri
    global count
    global nt
    nt=an
    cri=acri
    if type(adicttrt)==type({}):
        dicttrt=adicttrt
        dictcon=adictcon
        key=dicttrt.keys()
    else:
        dicttrt={"X1":adicttrt}
        dictcon={"X1":adictcon}
        key=dicttrt.keys()
    ntrt=len(dicttrt[dicttrt.keys()[0]])
    ncon=len(dictcon[dictcon.keys()[0]])
    markedtrt=[False]*ntrt
    markedcon=[False]*ncon

    result=searchLargestGraphs()
    dicttrt=None
    dictcon=None
    markedtrt=None

    markedcon=None

    ntrt = None
    ncon = None
    cri = None
    count=0
    nt=None
    return result



def getDistanceEulucid(i,j):  ##R index
    global dicttrt
    global dictcon
    global key
    sum=0

    for item in key:
        sum+=math.pow(dicttrt[item][i]-dictcon[item][j],2)
    return math.sqrt(sum)

def searchLargestGraphs():
    global ntrt
    global ncon
    global cri
    global markedtrt
    global markedcon
    global nt
    resulttrt=[]
    resultcon=[]
    result=[]
    largest=[]
    #templist=np.setdiff1d(range(ntrt),markedtrt)
    #while len(templist)>0:
    for tid in range(ntrt):
        if markedtrt[tid]==False:
            tempresult=searchForOneNode(tid,1)
            #templist=np.setdiff1d(range(ntrt),markedtrt)
            resulttrt = tempresult[0]
            resultcon = tempresult[1]
            result.append([resulttrt,resultcon])



    return result

def searchForOneNode(index,tc): ##python index
    global dicttrt
    global dictcon
    global markedtrt
    global markedcon
    global cri
    global ncon
    global ntrt
    stack=[]
    resulttrt=[]
    resultcon=[]
    if not [index,tc] in stack :
        if tc==1:
            markedtrt[index]=True ##
            resulttrt.append(index)
        elif tc==0:
            markedcon[index]=True ##
            resultcon.append(index)
        stack.append([index,tc])
        
    else:
        return None
    while len(stack)>0:
        temp=stack.pop()
        tempindex=temp[0]
        temptc=temp[1]
        if temptc==1:
            for cindex in range(ncon):
                if markedcon[cindex]==False:
                    tempdist=getDistanceEulucid(tempindex,cindex)
                    if tempdist<cri:
                        markedcon[cindex]=True #
                        stack.append([cindex,0]) #
                        resultcon.append(cindex)#
        if temptc==0:
            for tindex in range(ntrt):
                if markedtrt[tindex]==False:
                    tempdist=getDistanceEulucid(tindex,tempindex)
                    if tempdist<cri:
                        markedtrt[tindex]=True
                        stack.append([tindex,1])
                        resulttrt.append(tindex)

    return [resulttrt,resultcon]  ##returns python index


def listlistlist(alist):
    return [[[1,2,3],[1.1,1.2,1.3]],[[4,5,6],[4.4,5.5,6.6]],[[7,8,9],[7.7,8.8,9.9]]]

# import math
# dicttrt={"x1":[0.1,0.2,1.1,1.2]}
# dictcon={"x1":[0.11,0.21,0.22,1.11,1.21]}
# cri=0.3
# markedtrt=[False]*4
# markedcon=[False]*5
# ntrt=4
# ncon=5
# key=["x1"]
# r=searchForOneNode(0,1)